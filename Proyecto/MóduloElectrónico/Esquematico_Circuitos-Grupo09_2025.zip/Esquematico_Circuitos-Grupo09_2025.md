﻿1 2 3 4 5![](Aspose.Words.89280314-b129-49ca-ada1-96d08082e240.001.png)

A A

+3.3V M1 +5V +3.3V 223517

51 LVLV1 HV2HV1HV 192016

23 LV2 HV3 18

FG-PM2.54-1-04P-H8.5U6 4 LV3LV4 HV4HV5 1714

1 2 U2 1 87 LV6LV5 HV6 13

ESP32 WROOM\_mg GND 2 12 9 LV7 HV7 12

GND +3.3V 3 3 10 LV8 HV8 11

4 4 6 GND GND 15

~~21~~ 3V3 ~~30~~ GND

~~2~~ IO24IO20 ~~29~~ MQ135U1

EN ~~26~~

GND ~~3~~ SENSOR\_VP IO23IO19 ~~25~~

B ~~4~~ IO18 ~~24~~ B

SENSOR\_VN ~~23~~

~~29~~ IO17IO5 ~~22 28~~ U0TXD IO27 ~~37~~

GND U0RXD IO26 ~~26~~

IO25 ~~25~~

~~1~~ IO33 ~~33 16~~ GND IO32 ~~32~~

~~31~~ GND IO35 ~~6~~ +3.3V

GND GND IO34 ~~5~~ +3.3V

DHT22

1

2 VDD

C 3 SDA C

4 GNDSCK

U10

2x16 LCD to i2c +3.3V

1

VSS

2

VDD

3

VO

4

RS

5

R/W

6 GND

E

7

DB0

8

DB1

9

DB2

10

DB3

11

DB4

12 +3.3V

DB5

13

DB6

14

D DB7 15 VCC U8 D

LEDA

16 POT

LEDK

TITLE:

GND GND Sheet\_1 REV: 1.0 Company: UPCH Sheet: 1/1![](Aspose.Words.89280314-b129-49ca-ada1-96d08082e240.002.png)

Date: 2025-11-06 Drawn By: AntonyZu ñiga

1 2 3 4 5
